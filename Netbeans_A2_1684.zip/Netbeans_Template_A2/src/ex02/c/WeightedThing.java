package ex02.c;

public interface WeightedThing {
    
}
