package ex02.c;


public class Item {

}
