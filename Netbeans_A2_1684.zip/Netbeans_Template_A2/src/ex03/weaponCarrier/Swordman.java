package ex03.weaponCarrier;

import ex03.warrior.Warrior;
import ex03.weapon.Weapon;
import ex03.weapon.Sword;


public class Swordman extends Soldier {
    //Constructor #1
    public Swordman(String firstName,String lastName){
        super(firstName,lastName,5,4);
    }
    
    //Constructor #2
    public Swordman(String firstName,String lastName,int health){
        super(firstName,lastName,checkH(health),4);
    }
     private static int checkH(int health){
        if(health<5 && health>10){
            throw new IllegalArgumentException("Invalid value");
        }
        return health;
    }
    
    public void setWeapon(Weapon weapon){
        if(weapon==null){
            throw new NullPointerException("No weapon found");
        }
        try{
        if(weapon instanceof Sword){
            System.out.println("It's the right weapon");
            
        }else{
            throw new Exception("That is not a weapon for a Swordman");
        }
        }catch(Exception e){
            System.out.println(e.getMessage());
            System.exit(0);
        }
            
    }
    
    public String toString(){
        return "The Swordman "+getCallSign()+" has power "+getPower()+" and health "+getHealthCondition();
    }

    //Ta avala giati mou evgaze error epeidh den ulopoiountan oles oi me8odoi ths Soldier kai h Swordman den htan abstract
   @Override
    public void attack(Warrior adversary) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean isDefeated() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

}
