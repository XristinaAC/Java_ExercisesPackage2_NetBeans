package ex03.weapon;

public class Arc extends Weapon{
     public Arc(){
        super(2);
    }
    
    public Arc(int power){
        super(checkP(power));
        
    }
    
    private static int checkP(int power){
        if(power<1 && power>2){
            throw new IllegalArgumentException();
        }
        return power;
    }
   
    public String toString(){
        return "The sword has power "+getPower()+" and is owned by "+getHolder();
    }

}
