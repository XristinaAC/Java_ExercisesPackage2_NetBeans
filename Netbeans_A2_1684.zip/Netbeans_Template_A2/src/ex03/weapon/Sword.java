package ex03.weapon;


public class Sword extends Weapon{
     public Sword(){
        super(3);
    }
    
    public Sword(int power){
        super(checkP(power));
        
    }
    
    private static int checkP(int power){
        if(power<3 && power>4){
            throw new IllegalArgumentException();
        }
        return power;
    }
   
    public String toString(){
        return "The sword has power "+getPower()+" and is owned by "+getHolder();
    }

}
