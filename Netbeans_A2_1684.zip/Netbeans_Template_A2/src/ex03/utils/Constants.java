package ex03.utils;

/**
 * Class Constants
 *
 * @author
 */
public class Constants {

    // You can implement here the constant values of your code, for example
    //public static int ONE = 1;
}
