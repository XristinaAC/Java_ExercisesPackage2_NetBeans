package ex04.model.tests;

/*import ex04.model.classes.BusTicketsSeller;
import ex04.model.interfaces.BusTicketsSeller_ADT;

public class BusTicketSellerTest {

    public static void main(String[] args) {
        int StockTickets = 4;
        BusTicketsSeller_ADT bts = new BusTicketsSeller(StockTickets);
        // to be completed.
        //here you can test the busTicketSeller
        //for example try simple examples like select a ticket, then insert  
        //coins and finish the process. In the end check that the output is the 
        //one you were expecting!
    }

}*/
