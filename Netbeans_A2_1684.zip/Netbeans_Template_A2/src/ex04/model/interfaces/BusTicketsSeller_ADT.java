package ex04.model.interfaces;

/**
 * Specification of an ADT for selling bus tickets Status: exceptions are
 * missing
 */
public interface BusTicketsSeller_ADT {

}
