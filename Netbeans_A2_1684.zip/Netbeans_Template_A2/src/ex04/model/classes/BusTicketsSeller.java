package ex04.model.classes;

import ex04.model.interfaces.BusTicketsSeller_ADT;

/**
 * An implementation of the BusTicketsSeller_ADT specification.
 */
public class BusTicketsSeller implements BusTicketsSeller_ADT {

}
