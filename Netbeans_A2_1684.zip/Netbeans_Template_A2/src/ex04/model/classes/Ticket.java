package ex04.model.classes;

public class Ticket {

}
