package ex01;

public class Tester {

    public static void main(String[] args) {
       CloudStorage cM=new CloudStorage();
       
       cM.init();
      //System.out.println(cM.getCapacity());
      //H getCapacity den trexei, to exception pou vgazei einai java.lang.NullPointerException
    }
}
