package ex01;

public enum Type {CD,DVD,FlashDrive,HD,SSD}
